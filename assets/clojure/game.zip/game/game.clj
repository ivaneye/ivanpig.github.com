(ns game.game)

(def objects ["酒瓶" "水桶" "青蛙" "链条"])

(def en-cn {:east :东边
            :west :西边
            :upstairs :楼上
            :downstairs :楼下})

;objects

(def game-map (hash-map
                :起居室 ["你在巫师的房子的起居室里
                        - 有个巫师在沙发上大呼噜 -"
                      ["西边" "门" "花园"]
                      ["楼上" "楼梯" "阁楼"]]
                :花园 ["你在漂亮的花园里
                       - 你面前有一口井 -"
                     ["东边" "门" "起居室"]]
                :阁楼 ["你在巫师的房子的阁楼里
                       - 角落里有个巨大的火炉 -"
                     ["楼下" "楼梯" "起居室"]]))

(def object-locations (atom (hash-map
                        :酒瓶 :起居室
                        :水桶 :起居室
                        :链条 :花园
                        :青蛙 :花园)))

(def location (atom :起居室))

(defn describe-location [location game-map]
  (first (@location game-map)))

;(describe-location location game-map)

(defn describe-path [path]
  (str "那里有个" (second path) "可以从" (first path) "走到这里 -"))

;(describe-path ["西边" "门" "花园"])

(defn is-at? [obj loc obj-loc] (= (obj @obj-loc) loc))

;(is-at? :酒瓶 @location object-locations)

(defn describe-floor [loc objs obj-loc]
  (apply str (map #(str "你看见地上有一个" % " - ")
                     (filter #(is-at? (keyword %) @loc obj-loc) objs))))

;(describe-floor location objects object-locations)

(defn describe-paths [location game-map]
  (apply str (map describe-path (rest (get game-map @location)))))

;(describe-paths location game-map)

(defn look []
  (str (describe-location location game-map)
          (describe-paths location game-map)
          (describe-floor location objects object-locations)))

;(look)

(defn walk-direction [direction]
  (let [next (first (filter #(=  (direction en-cn) (keyword (first %)))
                            (rest (@location game-map))))]
    (cond next (do (reset! location (keyword (nth next 2))) (look))
          :else "此路不通 -")))

;@location
;(walk-direction :西边)
;(walk-direction :东边)

;macro
(defmacro walk [direction] `(walk-direction (keyword '~direction)))

;@location
;(walk 西边)
;(walk 东边)

(defn pickup-object [object]
  (cond (is-at? object @location object-locations)
        (do
          (reset! object-locations (assoc @object-locations object :picked))
          (str "你捡起了" (name object)))
        :else (str "你不能捡起" (name object))))

;(pickup-object :酒瓶)

(defmacro pick [object] `(pickup-object (keyword '~object)))

;(pick 酒瓶)

(defn inventory []
  (filter #(is-at? (keyword %) :picked object-locations) objects))

;(inventory)

(defn have? [object]
  (some #{object} (map keyword (inventory))))

(def chain-welded (atom false))

(def bucket-filled (atom false))

(defmacro game-action [command subj obj place & args]
  `(defn ~command [subject# object#]
      (cond (and (= @location (keyword '~place))
                 (= subject# (keyword '~subj))
                 (= object# (keyword '~obj))
                 (have? (keyword '~subj)))
            ~@args
            :else (str "我不能这么做"))))

(game-action weld 链条 水桶 阁楼
             (cond (and (have? :水桶) (reset! chain-welded true))
                   "链条焊接到了水桶上了 - "
                   :else "你不能进行焊接"))
;(weld :链条 :水桶)

(game-action dunk 水桶 井 花园
             (cond chain-welded
                   (do (reset! bucket-filled true)
                       "水桶装满了水")
                   :else "水太低了,够不到!"))

(game-action splash 水桶 巫师 起居室
             (cond (not bucket-filled) "水桶里没水!"
                   (have? :青蛙) "巫师醒了,看到你偷了它的青蛙 -
                                  他很生气,把你驱逐到了另一个世界 -
                                  你输了!"
                   :else "巫师醒了,很开心的和你打招呼 -
                          他送给你神奇的低脂肪甜甜圈 -
                          你赢了!"))