(ns game.client
  (:import (java.io BufferedInputStream InputStreamReader BufferedReader))
  (:use game.game))

(def walk-key {:a #(walk west),
               :s #(walk downstairs),
               :d #(walk east),
               :w #(walk upstairs)})
(def pick-key {:1 #(pick 青蛙),
               :2 #(pick 链条),
               :3 #(pick 水桶),
               :4 #(pick 酒瓶)})

(def action-key {:a1 #(weld :链条 :水桶),
                 :a2 #(dunk :水桶 :井),
                 :a3 #(splash :水桶 :巫师)})

(defn lp [str]
  (if (not= str "exit")
    (let [b (-> System/in (BufferedInputStream.) (InputStreamReader.) (BufferedReader.))
          s (.readLine b)
          w ((keyword s) walk-key)
          p ((keyword s) pick-key)
          a ((keyword s) action-key)]
      (if w (println (w)))
      (if p (println (p)))
      (if a (println (a)))
      (recur s))
    (println "exit")))

(println "Game Start")
(println "按键a:东边 按键d:西边 按键s:下楼 按键w:上楼")
(println "按键1:捡青蛙 按键2:捡链条 按键3:捡水桶 按键4:捡酒瓶")
(println "组合键a1:焊接 组合a2:打水 组合键a3:泼水")
(lp "")