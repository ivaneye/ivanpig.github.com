package org.embedosgi.host;

/**
 * Created by wangyifan on 2015/11/9.
 */
public class HostHello {
    public String name(){
        return "HostName";
    }
}
