package org.embedosgi.demo.impl;
import org.embedosgi.demo.Hello;
import org.embedosgi.host.HostHello;

/**
 * Created by wangyifan on 2015/11/9.
 */
public class HelloImpl implements Hello {
	public String say(String name) {
		System.out.println("HostHello ClassLoader = " + HostHello.class.getClassLoader());
		return "Hello " + name + new HostHello().name();
	}
}
