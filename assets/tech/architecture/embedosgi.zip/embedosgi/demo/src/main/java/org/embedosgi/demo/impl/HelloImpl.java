package org.embedosgi.demo.impl;
import org.embedosgi.demo.Hello;
import org.embedosgi.host.HostHello;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

/**
 * Created by wangyifan on 2015/11/9.
 */
public class HelloImpl implements Hello {
//	Logger logger = LoggerFactory.getLogger(HelloImpl.class);
	public String say(String name) {
//		logger.info("From HelloImpl Log" + logger.getClass().getClassLoader());
		System.out.println("HostHello ClassLoader = " + HostHello.class.getClassLoader());
		return "Hello " + name + new HostHello().name();
	}
}
