package org.embedosgi.activator;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import java.util.Dictionary;
import java.util.Hashtable;

/**
 * Created by wangyifan on 2015/11/9.
 */
public class Activator implements BundleActivator {
    public void start(BundleContext bundleContext) throws Exception {
        Dictionary<String,String> dict = new Hashtable<String, String>();
//        String version = this.getClass().getPackage().getImplementationVersion();
        String version = bundleContext.getBundle().getVersion().toString();
        dict.put("version",version);
        Object bean = Class.forName("org.embedosgi.demo.impl.HelloImpl").newInstance();
		bundleContext.registerService("org.embedosgi.demo.Hello", bean, dict);
        System.out.println("Reg Hello Service End!" + version);
    }

    public void stop(BundleContext bundleContext) throws Exception {

    }
}
