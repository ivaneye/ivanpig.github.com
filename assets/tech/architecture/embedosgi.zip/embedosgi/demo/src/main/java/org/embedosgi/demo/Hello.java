package org.embedosgi.demo;

/**
 * Created by wangyifan on 2015/11/9.
 */
public interface Hello {
    String say(String name);
}
